#pragma once

#include "device.h"

void checkBackpackUpdate();
extern bool HTEnableFlagReadyToSend;

extern device_t Backpack_device;
