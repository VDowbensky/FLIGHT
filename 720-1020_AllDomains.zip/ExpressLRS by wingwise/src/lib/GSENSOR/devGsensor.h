#pragma once

#include "device.h"
#include "CRSF.h"

extern device_t Gsensor_device;
