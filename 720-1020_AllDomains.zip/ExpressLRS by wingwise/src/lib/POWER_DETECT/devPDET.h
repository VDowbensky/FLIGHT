#pragma once

#include "device.h"

extern device_t PDET_device;