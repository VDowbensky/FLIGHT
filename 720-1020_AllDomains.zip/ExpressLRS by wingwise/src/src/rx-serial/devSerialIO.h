#pragma once

#include "device.h"

extern device_t Serial_device;
extern void crsfRCFrameAvailable();
